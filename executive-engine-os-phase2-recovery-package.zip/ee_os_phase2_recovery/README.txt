Executive Engine OS — Phase 2 Recovery / Implementation Package

Use these files in order when starting or testing a new build chat.

ORDER:
1. 01_master_recovery_context_placeholder.txt
2. 02_system_governance_documents.txt
3. 03_executive_operating_logic_v36030.txt
4. 04_frontend_architecture_v36040.txt
5. 05_backend_intelligence_router_v36050.txt
6. 06_executive_memory_system_v36060.txt
7. 07_phase2_build_plan_v36100.txt
8. 08_product_laws.txt

Purpose:
Move Executive Engine OS from governance into real implementation.

Core law:
BUILD OPERATIONAL LEVERAGE.
OPTIMIZE FOR EXECUTIVE ADVANTAGE.
